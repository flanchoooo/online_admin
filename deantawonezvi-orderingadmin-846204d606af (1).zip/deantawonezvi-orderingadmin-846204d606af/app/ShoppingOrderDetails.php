<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShoppingOrderDetails extends Model
{
    //
}
