@extends('layouts.app')

@section('content')
    @include('partials.home_menu.menu')
@endsection
