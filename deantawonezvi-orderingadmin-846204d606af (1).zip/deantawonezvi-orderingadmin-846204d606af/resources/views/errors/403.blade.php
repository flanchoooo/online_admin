@extends('layouts.app_error')

@section('title')
    Permission Error
@stop

@section('content')
    <div class="title">
        Whoops! Your need to talk to Admin.
    </div>
@stop
