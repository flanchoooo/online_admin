@extends('layouts.app_error')

@section('title')
    Be right back
@stop

@section('content')
    <center>
        <img src="{{asset('css/linear-communication/svg/robot.svg')}}" alt="500" style="width:55%">
    </center>
    <div class="title">
        Site under maintenance.
    </div>
@stop
