@extends('mail.account.layout')

@section('tr1')
    Your account has been blocked following 3 unsuccessful login attempts.
    Please contact admin for assistance.
@endsection

@section('tr2')
@endsection

@section('tr3')
@endsection