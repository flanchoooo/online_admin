@extends('mail.account.layout')

@section('tr1')
    Your account has been activated.
    You may login using the credentials you created during sign-up.
@endsection

@section('tr2')
@endsection
