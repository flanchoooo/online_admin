@extends('mail.account.layout')
@section('tr1')
    Please find a invoice attached for your order.
@endsection