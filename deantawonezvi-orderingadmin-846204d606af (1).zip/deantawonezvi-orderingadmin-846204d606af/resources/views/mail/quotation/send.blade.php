@extends('mail.account.layout')
@section('tr1')
    Please find a quotation attached for your enquiry
@endsection