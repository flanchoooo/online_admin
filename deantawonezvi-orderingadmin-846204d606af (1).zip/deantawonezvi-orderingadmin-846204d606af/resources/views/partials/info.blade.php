@if(session('info'))
    <div class="alert alert-info"><p>{{session('info')}}</p></div>
@endif